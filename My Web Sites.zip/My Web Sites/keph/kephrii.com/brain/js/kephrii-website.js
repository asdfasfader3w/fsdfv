/////////////////////
// www.flatline.tv //
/////////////////////
var parallaxSpeedFast = 1;
var parallaxSpeedSlow = 5;
var listStartOpen = ["schedule","about kephrii","stream artists","games","overwatch"];

// load global pages
function loadContent() {

  // header landing
  if ($("#header").hasClass("header-landing")) {
    loadFooter();
  } else {
    loadHeader();
  }

  // load header
  function loadHeader() {
    $(".page-header").load("brain/pages/page-header.html", function() {
      if ($(".sheets-container").hasClass("sheets-container")) {
        getSheets();
        loadFooter()
      }
    });
  }

  // load footer
  function loadFooter() {
    $(".page-footer").load("brain/pages/page-footer.html", function() {
      scrollParallax();
      scrollReveal();
      convertSVG();
    });
  }
} loadContent();

// header load
function headerLoad() {
  if ($(".header-landing").hasClass("header-landing")) {
    var posterVideo = document.getElementById("poster-video");

    posterVideo.addEventListener("loadeddata", function() {
      if (posterVideo.readyState >= 2) {
        posterVideo.play();
        $("#poster-cover").fadeOut(1000);
      }
    });
  }
} headerLoad();

////////////////////////////////////////////////////////////////////////////////
/// SHEETS /////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
function getSheets() {
  var $listRow = $(".list-row")[0].outerHTML;
  $(".list-row").remove();
  var $listWrap = $(".list-wrap")[0].outerHTML;
  $(".list-wrap").remove();
  var $sheetsSection = $(".sheets-section")[0].outerHTML;
  $(".sheets-section").remove();

  var pageTitle = $(".title h2").text().toLowerCase();

  // sheets tab
  switch(true) {
    case (pageTitle.includes("game settings")):
    sheetsTab = "Game_Settings";
    $(".settings").addClass("current");
    break;

    case (pageTitle.includes("pc specs")):
    sheetsTab = "PC_Specs";
    $(".specs").addClass("current");
    break;

    case (pageTitle.includes("faq")):
    sheetsTab = "FAQ";
    $(".faq").addClass("current");
    break;

    case (pageTitle.includes("guides")):
    sheetsTab = "Guides";
    $(".guides").addClass("current");
    break;

    case (pageTitle.includes("nutrition")):
    sheetsTab = "Nutrition";
    $(".nutrition").addClass("current");
    break;
  }

  // sheets url
  const baseUrl = "https://script.google.com/macros/s/AKfycbzcyMruEGG1-pt4NPIZ-HN2WUMDyvhLWYG4KObZaSWkhfdPxUlQ/exec";  // Please set your Web Apps URL.
  const para = {
    spreadsheetId: "1M140GqafYrG7HIg_fT9vhJwyhuPZVP3LCmslrfzAmlE",  // Please set your Google Spreadsheet ID.
    sheetName: sheetsTab  // Please set the sheet name you want to retrieve the values.
  };
  const q = new URLSearchParams(para);
  const url = baseUrl + "?" + q;
  fetch(url)
    .then(res => res.json())
    .then(res => {
      const values = res.values;
      // console.log(values);
      infoPage(values);
    }
  );

  function infoPage(values) {
    var sheets = values;
    var sheetsMax = values.length;
    // console.log(sheets);

    // clear loading
    $(".sheets-container").html("");

    for (var i = 2; i < sheetsMax; i++) {
      var infoType = sheets[i][0].toLowerCase();
      var infoCategory = sheets[i][1];
      var infoTitle = sheets[i][2];
      var infoItem = sheets[i][3];
      var infoExtra = sheets[i][4];
      var infoLink = sheets[i][5];

      // add categorys
      if (infoCategory) {
        $(".sheets-container").append($sheetsSection);
        $lastSection = $(".sheets-section:last-child");
        $lastSection.find(".category-title").text(infoCategory);
      }

      // section variations
      switch(true) {
        case (infoType == "info"):
        $lastSection.addClass("info-section");
        break;

        case (infoType == "fit"):
        $lastSection.addClass("info-section fit");
        break;
      }

      // add titles
      if (infoTitle) {
        $lastSection.append($listWrap);
        $lastWrap = $lastSection.find(".list-wrap:last-child");
        $lastWrap.find(".list-title").text(infoTitle);
      }

      // add items
      if (infoItem) {
        $lastWrap.append($listRow);
        $lastRow = $lastSection.find($lastWrap).find(".list-row:last-child");
        $lastRow.find(".item").text(infoItem);
      }

      // add/remove extras
      if (infoExtra) {
        $lastRow.find(".extra").text(infoExtra);
      } else {
        $lastRow.find(".extra").remove();
      }

      // add/remove links
      if (infoLink) {
        $lastRow.find(".link").attr("href", infoLink);
      } else {
        $lastRow.find(".link").remove();
      }
    }
    /////

    // section variations
    $(".info-section .list-title-wrap.collapse").removeClass("collapse");

    // enable buttons
    buttonCollapse();

    // section start open/collapse
    $(".sheets-section").each(function(index,element) {
      var elementCategory = $(element).find(".category-title").first().text().trim().toLowerCase();

      // start open
      if (listStartOpen.indexOf(elementCategory) >= 0) {

        // check each title, start open
        $(".list-wrap").each(function(index,element) {
          var elementTitle = $(element).find(".list-title-wrap").first().text().trim().toLowerCase();
          if (listStartOpen.indexOf(elementTitle) >= 0) {
            $(element).removeClass("hide");
            $(element).find(".list-row").show(0);
          }
        });

      // start collapse
      } else {
        $(element).addClass("hide");
        $(element).find(".list-wrap").hide(0);
      }
    });

    // if (sheetsHeight >= 3000) {
    if (sheetsTab != "FAQ_New") {
      $(".sheets-container").addClass("sticky-enabled");
      buttonStickyWindow();
    }
  }
  /////

}

function buttonCollapse() {
  // start collapsed
  $(".sheets-section:not(.info-section) .list-wrap").addClass("hide");
  $(".sheets-section:not(.info-section) .list-wrap > *:not('.collapse')").hide(0);
  var sheetsContainer = $(".sheets-container").children();
  var sheetsContainerMax = sheetsContainer.length;

  // click toggle
  $(".collapse").click(function(data) {
    var itemButton = data.currentTarget;
    var itemParent = data.currentTarget.parentElement;

    // find position
    for (var i = 0; i < sheetsContainerMax; i++) {
      if (sheetsContainer[i] == itemParent) {
        itemParentPos = i;
      }
    }

    // collapse
    if ($(itemParent).hasClass("hide") == true) {
      $(itemParent).find("> *:not(.collapse)").show(0);
      $(itemParent).removeClass("hide");

    } else {
      $(itemParent).find("> *:not(.collapse)").hide(0);
      $(itemParent).addClass("hide");

      // closing category, close open lists
      if ($(itemParent).hasClass("info-section") == false) {
        $(itemParent).find(".list-wrap > *:not('.collapse')").hide(0);
        $(itemParent).find(".list-wrap").addClass("hide");
      }
    }

    // sticky only category when collapse
    if ($(".sheets-container").hasClass("sticky-enabled") && $(itemButton).hasClass("category-title-wrap")) {
      buttonSticky(itemParentPos,true);
    }
    /////

  });
}

function buttonSticky(itemParentPos,clickCheck) {
  var offsetList = [];

  // each category offset
  $(".sheets-section").each(function(count,element) {
    var offsetNumber = $(element).find(".category-title-wrap").first().offset().top;
    offsetList.push(offsetNumber);
  });

  // each category window
  var offsetListLength = offsetList.length;
  var offsetWindowList = [];

  for (var i = 0; i < offsetListLength; i++) {
    offsetWindowList[i] = offsetList[i] - $(window).scrollTop();
    categoryPos = i+1;

    if (offsetWindowList[i] <= 0) {
      $(".sheets-section:not(:nth-child(" + categoryPos + ") .category-title-wrap.hide").removeClass("sticky");
      $(".sheets-section:nth-child(" + categoryPos + ") .category-title-wrap.hide:not(.sticky)").addClass("sticky");
    } else {
      $(".sheets-section:nth-child(" + categoryPos + ") .category-title-wrap.hide").removeClass("sticky");
    }
  }

  // window jump if first category is off screen
  if (clickCheck == true && offsetWindowList[0] <= 0) {
    $(window).scrollTop(offsetList[itemParentPos]);
  }
  /////

}

function buttonStickyWindow() {
  $(window).scroll(function() {
    buttonSticky();
  });
}

////////////////////////////////////////////////////////////////////////////////
/// SCRIPTS ////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
function getPlayerTitle() {
  $.get("https://decapi.me/twitch/title/kephrii", function(data) {
    $("#player-title").text(data);
  });
}

function hideChat() {
  $("#chat-hide").toggleClass("player-hide");

  if ($("#chat-hide").hasClass("player-hide")) {
    $("button.chat").text("Show Chat");
  } else {
    $("button.chat").text("Hide Chat");
  }
}

function convertSVG() {
  $("img.svg").each(function() {
    var imgHTML = $(this);
    var imgURL = imgHTML.attr("src");
    var imgClass = imgHTML.attr("class");

    $.get(imgURL, function(data) {
      var svgHTML = $(data).find("svg");

      if (imgClass != undefined) {
        svgHTML.addClass(imgClass);
      }

      imgHTML.replaceWith(svgHTML);
    });
    /////

  });
}

function scrollParallax() {
  var elementList = [];

  // find all parallax
  $(".parallax").each(function(count,element) {
    elementList.push(element);
  });

  var elementListMax = elementList.length;

  // start scroll
  $(window).scroll(function() {
    var posWindowTop = $(window).scrollTop();

    for (var i = 0; i < elementListMax; i++) {
      if ($(elementList[i]).hasClass("fast")) {
        positionParallax = Math.floor(posWindowTop / parallaxSpeedFast);
      } else {
        positionParallax = Math.floor(posWindowTop / parallaxSpeedSlow);
      }

      $(elementList[i]).css("transform", "translateY(-" + positionParallax + "px)");
    }
  });
  /////

}

function scrollReveal() {
  // scroll reveal
  ScrollReveal().reveal('.title', {distance: '20px', duration: 500, delay: 200, viewOffset: {bottom: 100}});
  ScrollReveal().reveal('.shirt', {distance: '20px', duration: 500, delay: 300});

  ScrollReveal().reveal('.twitch',    {distance: '20px', duration: 500, delay: 300});
  ScrollReveal().reveal('.youtube',   {distance: '20px', duration: 500, delay: 400});
  ScrollReveal().reveal('.twitter',   {distance: '20px', duration: 500, delay: 500});
  ScrollReveal().reveal('.instagram', {distance: '20px', duration: 500, delay: 600});

  // smooth scroll
  $("#jump").smoothScroll({
    offset: 0,
    direction: 'top',
    scrollTarget: null,
    autoFocus: false,
    delegateSelector: null,
    beforeScroll: function() {},
    afterScroll: function() {},
    easing: 'easeInOutQuint',
    speed: 1600,
    autoCoefficient: 2,
    preventDefault: true
  });

  // toggle menu
  $(".toggle-menu").click(function() {
    $("#menu-container").toggleClass("show");
  });
  /////

}
