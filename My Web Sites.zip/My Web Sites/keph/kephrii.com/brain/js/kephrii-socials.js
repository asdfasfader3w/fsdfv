/////////////////////
// www.flatline.tv //
/////////////////////
function getSocials() {
  $.get("brain/php/index.php", function(data) {
    // console.log(data);

    // var numbersList = [data.twitch, data.twitter, data.youtube, data.instagram];
    var numbersList = [data.twitch, data.twitter, data.youtube, 44000];
    var socialsList = [];

    for (i = 0; i < numbersList.length; i++) {
      var numberString = numbersList[i].toString();
      var numberLength = numberString.length;

      switch(true) {
        case (numberLength === 7):
        var numberFormat = parseFloat(numberString.slice(0,2) / 10);
        socialsList.push(numberFormat + "M");
        break;

        case (numberLength === 6):
        var numberFormat = parseFloat(numberString.slice(0,3));
        socialsList.push(numberFormat + "K");
        break;

        case (numberLength === 5):
        var numberFormat = parseFloat(numberString.slice(0,3) / 10);
        socialsList.push(numberFormat + "K");
        break;
      }
    }

    // console.log(socialsList);
    $(".twitch .stats .number").text(socialsList[0]);
    $(".twitter .stats .number").text(socialsList[1]);
    $(".youtube .stats .number").text(socialsList[2]);
    $(".instagram .stats .number").text(socialsList[3]);
    /////

  }, "json");
} getSocials();
